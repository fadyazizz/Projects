package simulation;

import java.io.Serializable;

public interface Simulatable extends Serializable{
public void cycleStep();
}
