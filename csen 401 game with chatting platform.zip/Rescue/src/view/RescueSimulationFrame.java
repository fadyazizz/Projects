package view;

import javax.swing.JFrame;

public class RescueSimulationFrame extends JFrame{

	public RescueSimulationFrame()  {
		
	}

}
