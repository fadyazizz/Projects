package view;

import javax.swing.JLabel;

public class RescueSimulationLabel extends JLabel  {

	public RescueSimulationLabel() {
		// TODO Auto-generated constructor stub
	}
	public RescueSimulationLabel(String s) {
		super(s);
	}

}
