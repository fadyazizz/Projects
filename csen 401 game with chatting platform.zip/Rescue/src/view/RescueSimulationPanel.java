package view;

import javax.swing.JPanel;

public class RescueSimulationPanel extends JPanel  {

	public RescueSimulationPanel() {
		// TODO Auto-generated constructor stub
	}

}
